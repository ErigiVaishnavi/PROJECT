from django import forms

# class Sign_Up(forms.Form):
#     name = forms.CharField(max_length = 50,label = '')